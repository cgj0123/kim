/* assets/script.js */
jQuery(document).ready(function ($) {
    $(".accordion-tab").on("click", function () {
        const index = $(this).index();

        // Toggle active class on tabs
        $(".accordion-tab").removeClass("active");
        $(this).addClass("active");

        // Show corresponding content
        $(".accordion-content").removeClass("active");
        $(".accordion-content").eq(index).addClass("active");
    });
});
