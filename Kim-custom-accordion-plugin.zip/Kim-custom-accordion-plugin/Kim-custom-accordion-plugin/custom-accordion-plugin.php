<?php
/**
 * Plugin Name: Custom Accordion Plugin
 * https://blog.lekims.com/
 * Description: A plugin to add accordion tabs with Elementor and shortcode support.
 * Version: 1.0
 * Author: Kim资源分享网
 */

// Check if Elementor is active
function custom_accordion_check_elementor() {
    if (!did_action('elementor/loaded')) {
        // Display admin notice if Elementor is not active
        add_action('admin_notices', function () {
            echo '<div class="error"><p><strong>Custom Accordion Plugin:</strong> Elementor must be installed and activated to use this plugin.</p></div>';
        });
        return false;
    }
    return true;
}

if (custom_accordion_check_elementor()) {
    // Include Elementor widget file
    require_once(CUSTOM_ACCORDION_PLUGIN_PATH . 'includes/elementor-widget.php');
}


// Exit if accessed directly
if (!defined('ABSPATH')) exit;

// Define plugin constants
define('CUSTOM_ACCORDION_PLUGIN_URL', plugin_dir_url(__FILE__));
define('CUSTOM_ACCORDION_PLUGIN_PATH', plugin_dir_path(__FILE__));

// Load assets
function custom_accordion_enqueue_assets() {
    wp_enqueue_style('custom-accordion-style', CUSTOM_ACCORDION_PLUGIN_URL . 'assets/style.css');
    wp_enqueue_script('custom-accordion-script', CUSTOM_ACCORDION_PLUGIN_URL . 'assets/script.js', ['jquery'], null, true);
}
add_action('wp_enqueue_scripts', 'custom_accordion_enqueue_assets');

function render_custom_accordion($atts) {
    $tabs = [
        'Technical data' => 'Technical data content here.',
        'Applications' => 'Applications details here.',
        'Product documentation' => 'Documentation links here.',
    ];

    ob_start(); ?>
    <div class="custom-accordion">
        <div class="accordion-tab-menu">
            <?php foreach ($tabs as $title => $content) : ?>
                <div class="accordion-tab"><?php echo esc_html($title); ?></div>
            <?php endforeach; ?>
        </div>
        <div class="accordion-content-wrapper">
            <?php foreach ($tabs as $title => $content) : ?>
                <div class="accordion-content"><?php echo esc_html($content); ?></div>
            <?php endforeach; ?>
        </div>
    </div>
    <?php return ob_get_clean();
}
add_shortcode('custom_accordion', 'render_custom_accordion');

// Include Elementor widget
require_once CUSTOM_ACCORDION_PLUGIN_PATH . 'includes/elementor-widget.php';
