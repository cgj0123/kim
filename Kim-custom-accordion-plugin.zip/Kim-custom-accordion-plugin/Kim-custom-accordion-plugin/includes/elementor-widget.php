<?php

if (!defined('ABSPATH')) exit; // Exit if accessed directly

use Elementor\Widget_Base;

class Custom_Accordion_Widget extends Widget_Base {
    public function get_name() {
        return 'custom_accordion';
    }

    public function get_title() {
        return __('Custom Accordion', 'text-domain');
    }

    public function get_icon() {
        return 'eicon-accordion';
    }

    public function get_categories() {
        return ['general'];
    }

    protected function _register_controls() {
        // Add widget controls here
    }

    protected function render() {
        // Render the widget's output
    }
}

// Register widget
function register_custom_accordion_widget($widgets_manager) {
    require_once(__DIR__ . '/elementor-widget.php');
    $widgets_manager->register_widget_type(new \Custom_Accordion_Widget());
}
add_action('elementor/widgets/register', 'register_custom_accordion_widget');


class Custom_Accordion_Elementor_Widget extends \Elementor\Widget_Base {
    public function get_name() {
        return 'custom_accordion';
    }

    public function get_title() {
        return __('Custom Accordion', 'custom-accordion');
    }

    public function get_icon() {
        return 'eicon-toggle';
    }

    public function get_categories() {
        return ['general'];
    }

    protected function _register_controls() {
        $this->start_controls_section(
            'accordion_section',
            [
                'label' => __('Accordion Settings', 'custom-accordion'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'tabs',
            [
                'label' => __('Tabs', 'custom-accordion'),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => [
                    [
                        'name' => 'tab_title',
                        'label' => __('Tab Title', 'custom-accordion'),
                        'type' => \Elementor\Controls_Manager::TEXT,
                        'default' => __('Tab Title', 'custom-accordion'),
                    ],
                    [
                        'name' => 'tab_content',
                        'label' => __('Tab Content', 'custom-accordion'),
                        'type' => \Elementor\Controls_Manager::WYSIWYG,
                    ],
                ],
                'default' => [
                    ['tab_title' => 'Tab 1', 'tab_content' => 'Content 1'],
                    ['tab_title' => 'Tab 2', 'tab_content' => 'Content 2'],
                ],
            ]
        );

        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        ?>
        <div class="custom-accordion">
            <div class="accordion-tab-menu">
                <?php foreach ($settings['tabs'] as $index => $tab) : ?>
                    <div class="accordion-tab"><?php echo esc_html($tab['tab_title']); ?></div>
                <?php endforeach; ?>
            </div>
            <div class="accordion-content-wrapper">
                <?php foreach ($settings['tabs'] as $index => $tab) : ?>
                    <div class="accordion-content"><?php echo $tab['tab_content']; ?></div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php
    }
}

add_action('elementor/widgets/widgets_registered', function () {
    \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new \Custom_Accordion_Elementor_Widget());
});
