<?php
/**
 * Plugin Name: Kim Custom Accordion Plugin
 * Plugin URI: https://blog.lekims.com/
 * Description: A plugin to add accordion tabs with Elementor and shortcode support.
 * Version: 1.0
 * Author: Kim资源分享网
 * Author URI: https://blog.lekims.com/
 * License: GPL2
 */

// 如果未激活 Elementor，则显示提示

add_actio

ad
add_action('admin_notices', 'custom_accordion_plugin_check_elementor');

fu
function custom_accordion_plugin_check_elementor() {
    
    i

 
if (!is_plugin_active('elementor/elementor.php')) {
        
     
?>
        <div 
        

    
class="notice notice-error">
            <p>
                <?php _e('Custom Accordion Plugin requires Elementor to be installed and activated.', 'custom-accordion-plugin'); ?>
                <a href="https://elementor.com" target="_blank">
                    <?php _e('Get Elementor', 'custom-accordion-plugin'); ?>
                </a>
            </p>
        </div>
        <?php
    }
}

// 如果未激活 Elementor，则显示提示

add_actio

ad
add_action('admin_notices', 'custom_accordion_plugin_check_elementor');

fu
function custom_accordion_plugin_check_elementor() {
    
    i

 
if (!is_plugin_active('elementor/elementor.php')) {
        
     
?>
        <div 
        

    
class="notice notice-error">
            <p>
                <?php _e('Custom Accordion Plugin requires Elementor to be installed and activated.', 'custom-accordion-plugin'); ?>
                <a href="https://elementor.com" target="_blank">
                    <?php _e('Get Elementor', 'custom-accordion-plugin'); ?>
                </a>
            </p>
        </div>
        <?php
    }
}

// 如果未激活 Elementor，则阻止插件加载功能
add_action('plugins_loaded', 'custom_accordion_plugin_init');
function custom_accordion_plugin_init() {
    
    i
if (!is_plugin_active('elementor/elementor.php')) {
        
        re

      

 
return; // Elementor 未激活时，停止插件运行
    }

    
    }

   
// 在这里添加插件的主功能代码
    
    a

   
add_action('elementor/widgets/widgets_registered', 'custom_accordion_plugin_register_widgets');
}

// 注册自定义小部件（仅示例）

functio

funct

fu
function custom_accordion_plugin_register_widgets($widgets_manager) {
    
   
// 添加自定义小部件逻辑
}


}

`

}

// Exit if accessed directly
if (!defined('ABSPATH')) exit;

// Define plugin constants
define('CUSTOM_ACCORDION_PLUGIN_URL', plugin_dir_url(__FILE__));
define('CUSTOM_ACCORDION_PLUGIN_PATH', plugin_dir_path(__FILE__));
define('CUSTOM_ACCORDION_PLUGIN_VERSION', '1.0');

// Check if Elementor is active
function custom_accordion_check_elementor() {
    if (!did_action('elementor/loaded')) {
        // Display admin notice if Elementor is not active
        add_action('admin_notices', function () {
            echo '<div class="error"><p><strong>Custom Accordion Plugin:</strong> Elementor must be installed and activated to use this plugin. <a href="https://wordpress.org/plugins/elementor/" target="_blank">Get Elementor</a></p></div>';
        });
        return false;
    }
    return true;
}

if (custom_accordion_check_elementor()) {
    // Include Elementor widget file
    $widget_file = CUSTOM_ACCORDION_PLUGIN_PATH . 'includes/elementor-widget.php';
    if (file_exists($widget_file)) {
        require_once $widget_file;
    } else {
        add_action('admin_notices', function () {
            echo '<div class="error"><p><strong>Custom Accordion Plugin:</strong> Elementor widget file is missing.</p></div>';
        });
    }
}

// Enqueue scripts and styles
function custom_accordion_enqueue_assets() {
    wp_enqueue_style('custom-accordion-style', CUSTOM_ACCORDION_PLUGIN_URL . 'assets/style.css', [], CUSTOM_ACCORDION_PLUGIN_VERSION);
    wp_enqueue_script('custom-accordion-script', CUSTOM_ACCORDION_PLUGIN_URL . 'assets/script.js', ['jquery'], CUSTOM_ACCORDION_PLUGIN_VERSION, true);
}
add_action('wp_enqueue_scripts', 'custom_accordion_enqueue_assets');

// Shortcode functionality
function custom_accordion_shortcode($atts, $content = null) {
    $atts = shortcode_atts([
        'title' => 'Accordion Title',
    ], $atts, 'custom_accordion');

    // Sanitize and construct output
    $title = esc_html($atts['title']);
    $content = do_shortcode($content);

    return '<div class="custom-accordion">
                <h3 class="accordion-title">' . $title . '</h3>
                <div class="accordion-content">' . wp_kses_post($content) . '</div>
            </div>';
}
add_shortcode('custom_accordion', 'custom_accordion_shortcode');
